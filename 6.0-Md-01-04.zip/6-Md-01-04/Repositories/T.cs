﻿namespace _6_Md_01_04.Repositories
{
    internal class T
    {
    }
}