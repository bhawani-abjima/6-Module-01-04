﻿namespace _6_Md_01_04.Repositories
{
    public interface IRepositary<T> where T :IEntity
    {
        void Add(T item);
        T GetById(int id);
        void Remove(T item);
        void Save();
    }
}