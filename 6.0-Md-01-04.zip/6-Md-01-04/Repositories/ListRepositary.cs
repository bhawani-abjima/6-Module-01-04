﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Nest;

namespace _6_Md_01_04.Repositories
{
    public class ListRepositary<T> IRepository<T> where T:IEntity
    {
        private readonly List<T> _items = new(); 
        
        public T GetById(int id)
        {
            return _items.Single(item => item.Id == id);
        }
        public void Add(T item)
        {
            item.Id = _item.Count + 1;
            _item.Add(item);
        }
        public void Remove(T item) 
        {
           _item.Remove(item);
        }
        public void Save()
        {
            foreach(var item in_items)
            {
                Console.WriteLine(item);
            }
        }

    }


}
