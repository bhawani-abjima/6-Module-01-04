﻿using Microsoft.EntityFrameworkCore;
usind _6_Md_01_04.WiredBrainCoffee.StorageApp.Entities;

namespace _6_Md_01_04.Repositories
{
    public class SqlRepositary<T> : IRepositary<T> where T : class, IEntity
    {
        private readonly DbContext _dbContext;
        private readonly DbSet<T> _dbSet;

        public SqlRepositary(DbContext dbContext)
        {
            _dbContext = dbContext;
            _dbSet = _dbContext.Set<T>();
        }

        public T GetById(int id) => _dbSet.Find(id);
        public void Add(T item)
        {
            _dbSet.Add(item);
        }
        public void Remove(T item)
        {
            _dbSet.Remove(item);
        }
        public void Save()
        {
            _dbContext.SaveChanges();

        }
    }


}
