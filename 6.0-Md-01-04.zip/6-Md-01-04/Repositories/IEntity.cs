﻿namespace _6_Md_01_04.Repositories
{
    public interface IEntity
    {
    }
}