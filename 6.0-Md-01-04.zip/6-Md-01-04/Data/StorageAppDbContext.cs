﻿using _6_Md_01_04.Entities;
using Microsoft.EntityFrameworkCore;

namespace _6_Md_01_04.Data
{
    public class StorageAppDbContext: DbContext

    {
        public DbSet<Employee> Employees=>Set <Employee>();    
        public DbSet<Organisation> Organisations=> Set <Organisation>();

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)      //Using microsoft.Entity Framework
        {
            base.OnConfiguring(optionsBuilder);
            optionsBuilder.UseInMemoryDatabase("StorageAppDb");
         
        }

    }
}
