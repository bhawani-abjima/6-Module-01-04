﻿namespace WiredBrainCoffee.StorageApp
{
    internal class Organization
    {
        public string Name { get; set; }
    }
}