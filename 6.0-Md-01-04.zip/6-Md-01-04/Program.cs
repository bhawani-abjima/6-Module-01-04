﻿using System;
using System.Security;
using _6_Md_01_04.Data;
using _6_Md_01_04.Entities;
using _6_Md_01_04.Repositories;
using Microsoft.EntityFrameworkCore;

namespace WiredBrainCoffee.StorageApp
{
    class Program
    {
        private static readonly object employeeRepository;

        static void Main(string[] args)
        {
            var employeeRepository = new SqlRepositary<Employee>(StorageAppDbContext();            //working with generic classes
            employeeRepository.Add(new Employee { FirstName = "Julia" });
            employeeRepository.Add(new Employee { FirstName = "Ana" });
            employeeRepository.Add(new Employee { FirstName = "Peter" });

            employeeRepository.Save();

            var organizationRepositary = new GenericRepository<Organization>();
            organizationRepositary.Add(new Organization { Name = "pluralsight" });
            organizationRepositary.Add(new Organization { Name = "globalsite" });

            organizationRepositary.Save();
            Console.ReadLine();

        }

        
        private static void GetEmployeeById(IRepositary<Employee> EmployeeRepositary)
        {
            var employee = employeeRepository.GetById(2);
            Console.WriteLine($"Employee with Id 2:"{ employee.FirstName}");


        }
        private static void AddEmployees(IRepositary<Employee> EmployeeRepositary)
        {
            employeeRepository.Add(new Employee { FirstName = "JUlia" });
            employeeRepository.Add(new Employee { FirstName = "Anna" });
            employeeRepository.Add(new Employee { FirstName = "thomas" });
            employeeRepository.Save();

        }

        private static void AddOrganizations(IRepositary<Employee> OrganizationRepositary)
        {
            employeeRepository.Add(new Employee { FirstName = "JUlia" });
            employeeRepository.Add(new Employee { FirstName = "Anna" });
            employeeRepository.Add(new Employee { FirstName = "thomas" });
            employeeRepository.Save();
        }




    }

}